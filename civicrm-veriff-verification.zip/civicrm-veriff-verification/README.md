# CiviCRM Veriff Membership Verification

WordPress-Plugin, das bei einer CiviCRM-Mitgliedschaft (Stripe-Zahlung) den
Namen des Users per [Veriff](https://www.veriff.com/) verifiziert, bevor das
Formular abgeschickt / die Subscription angelegt werden kann.

## Funktionsweise

1. Auf dem konfigurierten CiviCRM-Formular (z.B. der Contribution-Page mit
   Membership-Block) erscheint ein Button „Identität mit Veriff verifizieren“.
2. Klick erstellt serverseitig eine Veriff-Session (`POST /v1/sessions`),
   inkl. Vor-/Nachname als `person`-Daten. Ist in eurem Veriff-Account
   **InitData Matching** aktiviert, vergleicht Veriff automatisch den
   angegebenen Namen mit dem aus dem Ausweisdokument extrahierten Namen.
3. Der Nutzer schließt den Veriff-Flow in einem Popup-Fenster ab.
4. Veriff sendet das Ergebnis asynchron an den Decision-Webhook
   (`/wp-json/civiveriff/v1/webhook`), signiert per HMAC-SHA256 mit eurem
   Shared Secret. Das Plugin prüft die Signatur, speichert Status +
   Namensabgleich in einer eigenen DB-Tabelle und legt optional eine
   CiviCRM-Aktivität als Audit-Trail an.
5. Das Frontend pollt den Status und schaltet erst dann den Submit frei.
6. **Serverseitig** wird zusätzlich über `civicrm_validateForm` erzwungen,
   dass für den Kontakt eine `approved`-Entscheidung mit Namensübereinstimmung
   vorliegt – die Formular-Freischaltung im Browser ist nur UX, kein
   Sicherheitsmechanismus.

## Installation

1. Ordner `civicrm-veriff-verification` nach `wp-content/plugins/` kopieren.
2. Plugin im WP-Backend aktivieren (legt die Tabelle
   `wp_civiveriff_sessions` an).
3. Unter **Einstellungen → CiviCRM Veriff**:
   - Veriff API Key (`X-AUTH-CLIENT`) und Shared Secret eintragen
     (Veriff Customer Portal → Integrations).
   - API-Basis-URL prüfen/anpassen (stationspezifisch).
   - Formularklasse(n) eintragen, auf denen die Prüfung erscheinen soll.
4. Die angezeigte Webhook-URL im Veriff Customer Portal als
   „Decision Webhook“ hinterlegen.
5. Optional in Veriff **InitData Matching** aktivieren, damit der
   Namensabgleich direkt von Veriff durchgeführt wird (empfohlen). Ohne
   dieses Feature vergleicht das Plugin selbst (einfacher, toleranter
   String-Vergleich in `class-civiveriff-rest.php`).
6. In CiviCRM optional einen Activity Type „Identity Verification“ anlegen
   (Administer → Option Lists → Activity Types), damit das Audit-Log
   funktioniert.

## Bekannte Einschränkung auf Mobilgeräten

Der Veriff-Flow wird per `window.open()` in einem Popup geöffnet. Auf dem
Desktop funktioniert das zuverlässig: Nach Abschluss schließt sich das Popup
automatisch, der ursprüngliche Tab mit dem Formular bleibt unverändert offen
und schaltet den Submit-Button frei.

Auf einigen mobilen Browsern (v.a. iOS Safari) wird `window.open()` nach
einem asynchronen AJAX-Aufruf **nicht** als Popup, sondern als normale
Navigation im selben Tab behandelt. In diesem Fall verlässt der Nutzer die
Formularseite tatsächlich, und bereits eingegebene Formulardaten gehen beim
Zurückkehren verloren (CiviCRM baut das Formular bei der Rückkehr neu auf).
Das Plugin fängt das über eine eigene Bestätigungsseite
(`/veriff-verification-complete/`) ab und bietet einen "Zurück zur Anmeldung"-
Button, kann den Datenverlust aber nicht vollständig verhindern.

**Sauberer, aber aufwändigerer Fix:** Statt Popup/Redirect Veriffs offizielles
Web-SDK (InContext, läuft als Overlay/iframe direkt auf der Formularseite,
ohne die Seite je zu verlassen) einbinden. Das würde dieses Problem auf allen
Geräten vollständig lösen – das ist im aktuellen Stand des Plugins bewusst
noch nicht umgesetzt, um den Umfang überschaubar zu halten. Sag Bescheid,
falls du das als nächsten Schritt möchtest.

## Update-Hinweis (v1.0.0 → aktuelle Version)

Die erste Fassung dieses Plugins hat die Verifizierung an eine bereits
vorhandene CiviCRM `contact_id` gebunden. Auf einer öffentlichen
Neuanmeldeseite (z.B. „Mit-Glied werden") existiert zu diesem Zeitpunkt aber
noch **kein** Kontakt – das Formular wurde dadurch nie angezeigt. Die aktuelle
Version arbeitet stattdessen mit einem einmaligen **Token** pro
Formularaufruf; der echte Kontakt wird erst nach dem Absenden (über
`civicrm_postProcess`) nachträglich verknüpft. Einfach die Dateien
überschreiben – die Datenbanktabelle migriert sich beim nächsten Seitenaufruf
automatisch (neue Spalte `token`).

## Stellen, die ihr an euer Setup anpassen müsst

Im Code mit `ANPASSEN:` markiert, u.a.:

- **`CRM_Contribute_Form_Contribution_Main`** als Standard-Formularklasse –
  je nachdem ob ihr eine Contribution-Page mit Membership-Block, ein
  eigenständiges Membership-Signup-Formular oder ein Custom-Formular nutzt,
  muss die tatsächliche Formularklasse eingetragen werden. Am schnellsten
  findet ihr die Klasse per `error_log($formName)` in `civicrm_buildForm`
  temporär, oder in den CiviCRM-Logs/URL-Parametern (`?_qf_...`).
- **`get_form_contact_id()`**: Je nach Formular-Flow (neuer vs.
  bestehender Kontakt, eingeloggt vs. Gast) kann die Quelle der
  Kontakt-ID variieren.
- **jQuery-Selektor in `veriff-frontend.js`** (`findForm()`), falls euer
  Theme/CiviCRM-Template andere Formular- oder Feld-Namen verwendet.
- **Feldnamen `first_name` / `last_name`** im JS, falls euer Formular
  andere Feldnamen nutzt (z.B. bei mehreren Kontaktblöcken).

## Sicherheitshinweise

- Die eigentliche Durchsetzung passiert **serverseitig** in
  `CiviVeriff_CiviCRM::validateForm()` – das JS/Popup ist nur UX.
- Der Webhook-Endpunkt ist öffentlich erreichbar, wird aber über die
  HMAC-Signatur (`X-HMAC-SIGNATURE`, Shared Secret) abgesichert; ohne
  gültige Signatur wird der Request mit 401 abgelehnt.
- `create-session` ist über einen WP-Nonce pro Kontakt-ID abgesichert,
  verhindert aber keine grundsätzliche Manipulation der übergebenen
  `contact_id` durch einen eingeloggten Nutzer – für sensible Setups
  empfiehlt es sich, `contact_id` serverseitig zusätzlich gegen die
  aktuelle CiviCRM-/WP-Session zu validieren.
- Speichert keine Ausweisbilder o.ä. selbst – diese verbleiben bei Veriff;
  das Plugin speichert nur Status, verifizierten Namen und die rohe
  Decision-JSON zu Audit-Zwecken.

## Nicht enthalten / bewusst offengelassen

- Automatisches Blockieren der eigentlichen Stripe-Zahlung auf
  Payment-Processor-Ebene (zusätzlich zur Formular-Validierung) – je nach
  gewünschtem UX evtl. sinnvoll, aber setup-abhängig.
- Mehrsprachigkeit über CiviCRM/WPML hinaus (Texte sind aktuell hart auf
  Deutsch, liegen aber zentral in `class-civiveriff-civicrm.php` und
  `veriff-frontend.js`).

## Mindestalter (18 Jahre)

Zusätzlich zum Namensabgleich prüft das Plugin optional (standardmäßig aktiv),
ob das von Veriff aus dem Ausweisdokument gelesene Geburtsdatum ein
Mindestalter erfüllt (Standard: 18 Jahre, einstellbar unter Einstellungen →
CiviCRM Veriff). Das läuft komplett unabhängig von einem eventuellen
Geburtsdatum-Feld im Formular selbst - Grundlage ist ausschließlich das
verifizierte Ausweisdatum, nicht eine Selbstauskunft. Wird das Mindestalter
nicht erfüllt, wird das Formular genauso blockiert wie bei einem
Namens-Mismatch (serverseitig über `civicrm_validateForm` erzwungen).
